import {loadAdentaConfig} from "../src/loaders/index.ts"

const d = await loadAdentaConfig;

console.dir(d)
